/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trackcont;

/**
 *
 * @author Jeff
 */
public class TrackCont {
    int rangeStart;
    int rangeEnd;
    TrackCont_TrackBlock[] sectBlocks;
    TrackCont_Wrap main;
    ActiveBlocks[] fSwitchBlocks;
    ActiveBlocks[] pSwitchBlocks;
    ActiveBlocks[] crossBlocks;
    ActiveBlocks[] lightBlocks;
    ActiveBlocks[] extraBlocks;
    TrackCont_GUI gui;
    int contNum;
    boolean guiLook;
    
    private class ActiveBlocks{
        int blockNum;
        int sectNum;
        public ActiveBlocks(int bn,int sn){
            blockNum=bn;
            sectNum=sn;
        }
    }
    
    public TrackCont(int cNum,int start, int end, TrackCont_TrackBlock[] bp,TrackCont_Wrap wrap){
        contNum=cNum;
        sectBlocks=bp;
        rangeStart=start;
        rangeEnd=end;
        main=wrap;
        fSwitchBlocks=new ActiveBlocks[rangeEnd-rangeStart+1];
        pSwitchBlocks=new ActiveBlocks[rangeEnd-rangeStart+1];
        crossBlocks=new ActiveBlocks[rangeEnd-rangeStart+1];
        lightBlocks=new ActiveBlocks[rangeEnd-rangeStart+1];
        extraBlocks=new ActiveBlocks[rangeEnd-rangeStart+1];
        if(cNum==0)
            guiLook=true;
        else
            guiLook=false;
        findActiveBlocks();
        int i=0;
        while(sectBlocks[i]!=null && i<sectBlocks.length-1){
            i++;
        }
    }
    
    public void GUIoff(){
        guiLook=false;
    }
    public void GUIon(){
        guiLook=true;
        updateGUI();
    }
    
    public void addGUI(TrackCont_GUI g){
        gui=g;
        gui.addController(contNum,this);
    }
    
    private void findActiveBlocks(){
        int c=0;
        int s=0;
        int l=0;
        for(int i=0;i<rangeEnd-rangeStart+1;++i){
            if(sectBlocks[i].type ==1){
                fSwitchBlocks[s]=new ActiveBlocks(sectBlocks[i].blockNum,i);
                s++;
            }
            if(sectBlocks[i].type ==5){
                pSwitchBlocks[s]=new ActiveBlocks(sectBlocks[i].blockNum,i);
                s++;
            }
            if(sectBlocks[i].type ==2){
                crossBlocks[c]=new ActiveBlocks(sectBlocks[i].blockNum,i);
                c++;
            }
            if(sectBlocks[i].type ==3){
                lightBlocks[l]=new ActiveBlocks(sectBlocks[i].blockNum,i);
                l++;
            }
        }
    }
    
    public void update(int trainLoc){
        int i=0;
        while(sectBlocks[i]!=null && i<sectBlocks.length-5){
            if(sectBlocks[i].failure){
                setSpeed(sectBlocks[i].prevBlock,0);
            }
            else{
                setSpeed(sectBlocks[i].prevBlock,12);
            }
            ++i;
        }
        i=0;
        if(trainLoc>=rangeStart && trainLoc<rangeEnd){
            //if(sectBlocks[sectBlocks[trainLoc-rangeStart].nextBlock-rangeStart].failure){
            //    setSpeed(trainLoc,0);
            //}else{
            //    setSpeed(trainLoc,12);
            //}
            if(sectBlocks[trainLoc-rangeStart].nextBlock==-1){
                setSpeed(trainLoc,0);
            }
            if(sectBlocks[trainLoc-rangeStart].altNextBlock==-1 && (sectBlocks[trainLoc-rangeStart].type==1 && sectBlocks[trainLoc-rangeStart].state)){
                setSpeed(trainLoc,0);
            }
        }
        while(crossBlocks[i]!=null){
            if(sectBlocks[crossBlocks[i].sectNum-1].occupied || sectBlocks[crossBlocks[i].sectNum].occupied || sectBlocks[crossBlocks[i].sectNum+1].occupied){
                changeStateRequest(true,crossBlocks[i].blockNum);
            }else{
                changeStateRequest(false,crossBlocks[i].blockNum);
            }
            i++;
        }
        i=0;
        if(contNum==0){
            if(sectBlocks[sectBlocks.length-4].occupied || sectBlocks[sectBlocks.length-3].occupied || (sectBlocks[8].occupied && sectBlocks[8].state)){
                sectBlocks[8].state=true;
            }
            else{
                sectBlocks[8].state=false;
            }
        }
        updateGUI();
    }
    
    public void updateGUI(){
        if(guiLook){
            gui.clearBlocks();
            int j=sectBlocks.length-1;
            for(int i=0;i<rangeEnd-rangeStart+1;++i){
                gui.addBlock(i*120, 20,sectBlocks[i],true);
                if(sectBlocks[i].type==1){
                    gui.addBlock(i*120, 180,sectBlocks[j],false,1);
                    gui.addBlock((i+1)*120,180,sectBlocks[j-1],false);
                    j=j-2;
                } 
                if(sectBlocks[i].type==5){
                    gui.addBlock(i*120, 180,sectBlocks[j],false,2);
                    gui.addBlock((i-1)*120,180,sectBlocks[j-1],false);
                    j=j-2;
                }
            }
        }
    }
    
    public void updateGUI(String [] range){
        //gui.clearBlocks();
        updateGUI();
    }
    
    public int [] getRange(){
        return new int[]{rangeStart,rangeEnd};
    }
    
    public void changeStateRequest(boolean s, int bNum){
        main.setState(s, bNum);
    }
    public void setSwitch(int bNum,boolean s){
        main.setState(s, bNum);
    }
    public void setSpeed(int bNum,double speed){
        main.setSpeed(speed,bNum);
    }
    public void setAuth(int bNum,int auth){
        main.setAuth(auth,bNum);
    }
    public void trackFailure(){
        for(int i=0;i<rangeEnd-rangeStart+1;++i){
            setSpeed(i,0.0);
        }
    }
    public void trackWorks(){
        for(int i=0;i<rangeEnd-rangeStart+1;++i){
            setSpeed(i,12.0);
        }
    }
}
