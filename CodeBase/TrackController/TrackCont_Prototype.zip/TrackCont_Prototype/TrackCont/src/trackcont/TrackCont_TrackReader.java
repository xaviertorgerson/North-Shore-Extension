/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trackcont;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 *
 * @author Jeff
 */
public class TrackCont_TrackReader {
    TrackCont_TrackBlock trackBlocks[];
    
    public TrackCont_TrackReader(){
        trackBlocks=new TrackCont_TrackBlock[17];
        readTrack();
    }
    
    private void readTrack(){
        try(BufferedReader br=new BufferedReader(new FileReader("TrackCont_TestTrack.txt"))){
            String curLineS;
            int count=0;
            while((curLineS=br.readLine())!=null){
                String[] data=curLineS.split(",");
                //When the next and previous blocks are trivial it is marked by both of those fields being -1
                while(count<Integer.parseInt(data[0])){ //set unexciting blocks
                    trackBlocks[count]=new TrackCont_TrackBlock(count, 0, count+1,count-1);
                    count++;
                }
                int bNum=Integer.parseInt(data[0]);
                int t=Integer.parseInt(data[1]);
                if(data.length>=4){ //Set switch/abnormal blocks
                    int next=Integer.parseInt(data[2]);
                    int prev=Integer.parseInt(data[3]);
                    if(data.length==6){
                        int anext=Integer.parseInt(data[4]);
                        int aprev=Integer.parseInt(data[5]);
                        trackBlocks[count]=new TrackCont_TrackBlock(bNum,t,next,prev,anext,aprev);
                    }else
                        trackBlocks[count]=new TrackCont_TrackBlock(bNum,t,next,prev);
                }else{
                   trackBlocks[count]=new TrackCont_TrackBlock(bNum,t,++bNum,--bNum);
                }
                count++;
            }
        }
        catch(IOException e){
            System.out.println("failed to load file");
        }
    }
    public int getLength(){
        return trackBlocks.length;
    }
    public TrackCont_TrackBlock getBlockAtIndex(int index){
        return trackBlocks[index];
    }
    public void resetStates(){
        for(int i=0;i<trackBlocks.length;++i){
            if(trackBlocks[i]!=null){
                trackBlocks[i].state=false;
                trackBlocks[i].failure=false;
                trackBlocks[i].occupied=false;
                trackBlocks[i].heater=false;
                trackBlocks[i].speedLimit=12.0;
                trackBlocks[i].authority=2;
            }
        }
    }
    public TrackCont_TrackBlock[] getBlocksInRange(int start,int end){
        if(start>=0 && end < trackBlocks.length && start<end){
            TrackCont_TrackBlock[] rangeBlocks=new TrackCont_TrackBlock[end-start+5];//+4];
            int j=rangeBlocks.length-1;
            for(int i=start;i<=end;++i){
                rangeBlocks[i-start]=trackBlocks[i];
                if(trackBlocks[i].type==1 || trackBlocks[i].type==5){
                    if(trackBlocks[i].altNextBlock!=-1){
                        rangeBlocks[j]=trackBlocks[trackBlocks[i].altNextBlock];
                        rangeBlocks[j-1]=trackBlocks[trackBlocks[trackBlocks[i].altNextBlock].nextBlock];
                    }
                    else if(trackBlocks[i].altPrevBlock!=-1){
                        rangeBlocks[j]=trackBlocks[trackBlocks[i].altPrevBlock];
                        rangeBlocks[j-1]=trackBlocks[trackBlocks[trackBlocks[i].altPrevBlock].prevBlock];
                    }
                    j=j-2;
                }
            }
            return rangeBlocks;
        }else
            return null;
    }
}
