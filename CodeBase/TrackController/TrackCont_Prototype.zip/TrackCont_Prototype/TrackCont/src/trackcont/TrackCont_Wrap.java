/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trackcont;

import java.util.*;
import java.awt.event.*;
import javax.swing.Timer;
/**
 *
 * @author Jeff
 */
public class TrackCont_Wrap  implements Runnable{

    /**
     * @param args the command line arguments
     */
    TrackCont_GUI gui;
    TrackCont[] controllers;
    TrackCont_TrackReader trackBlocks;
    int guiStart=0;
    int guiEnd=0;
    int trainLoc=0;
    long timeNum;
    Timer time;
    
    public TrackCont_Wrap(){
        gui=new TrackCont_GUI(this);
        trackBlocks=new TrackCont_TrackReader();
        controllers=new TrackCont[2];
        controllers[0]=new TrackCont(0,0,9,trackBlocks.getBlocksInRange(0, 9),this);
        controllers[1]=new TrackCont(1,10,16,trackBlocks.getBlocksInRange(10, 16),this);
        controllers[0].addGUI(gui);
        controllers[1].addGUI(gui);
        controllers[0].update(0);
        input_loop();
    }
    
    public void input_loop(){
        int delay = 1000; //milliseconds
        ActionListener taskPerformer = new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                run();
            }
        };
        time=new Timer(delay, taskPerformer);
        //time.start();
        
        Scanner user_input = new Scanner( System.in );
        while(true){
            String input=new String(user_input.next());
            System.out.println(input);
            String[] inst=input.split("-");
            if(inst[0].equals("run")){
                time.start();
            }
            if(inst[0].equals("stop")){
                time.stop();
                gui.clearBlocks();
                trackBlocks.getBlockAtIndex(trainLoc).occupied=false;
                trackBlocks.resetStates();
            }
            if(inst[0].equals("train")){
                setTrain(Integer.parseInt(inst[1]));
            }
            if(inst[0].equals("failed")){
                setFailed(Integer.parseInt(inst[1]));
            }
            if(inst[0].equals("working")){
                setWorking(Integer.parseInt(inst[1]));
            }
            if(inst[0].equals("switch")){
                boolean state;
                if(inst[2].equals("up")){
                    state=true;
                }else{
                    state=false;
                }
                int bNum=Integer.parseInt(inst[1]);
                if(bNum<=controllers[0].rangeEnd){
                    controllers[0].setSwitch(bNum,state);
                }else{
                    controllers[1].setSwitch(bNum,state);
                }
            }
            if(inst[0].equals("speed")){
                int bNum=Integer.parseInt(inst[1]);
                double speed=Integer.parseInt(inst[2]);
                if(bNum<=controllers[0].rangeEnd){
                    controllers[0].setSpeed(bNum,speed);
                }else{
                    controllers[1].setSpeed(bNum,speed);
                }
            }
            if(inst[0].equals("auth")){
                int bNum=Integer.parseInt(inst[1]);
                int auth=Integer.parseInt(inst[2]);
                if(bNum<= controllers[0].rangeEnd){
                    controllers[0].setAuth(bNum,auth);
                }else{
                    controllers[1].setAuth(bNum,auth);
                }
            }
        }
    }
    public void run(){
        TrackCont_TrackBlock currentBlock=trackBlocks.getBlockAtIndex(trainLoc);
        TrackCont_TrackBlock nextBlock=trackBlocks.getBlockAtIndex(currentBlock.nextBlock);
        currentBlock.occupied=false;
        trainLoc=currentBlock.nextBlock;
        if(currentBlock.type==1 && currentBlock.state==true){
            if(currentBlock.altNextBlock!=-1){
                trainLoc=currentBlock.altNextBlock;
            }
        }else if(nextBlock.type==5){
            if(nextBlock.prevBlock==currentBlock.blockNum && nextBlock.state){
                //Train crashes
                trainLoc=-1;
            }
            if(nextBlock.altPrevBlock==currentBlock.blockNum && !nextBlock.state){
                //train crashes
                trainLoc=-1;
            }
        }
        if(currentBlock.speedLimit==0){
            trainLoc=currentBlock.blockNum;
        }
        trackBlocks.getBlockAtIndex(trainLoc).occupied=true;
        controllers[0].update(trainLoc);
        controllers[1].update(trainLoc);
        timeNum++;
    }
    
    public void startRun(){
        int delay = 1000; //milliseconds
        ActionListener taskPerformer = new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                run();
            }
        };
        time=new Timer(delay, taskPerformer);
        time.start();
    }
    
    public void setTrain(int newTrainLoc){
        trainLoc=newTrainLoc;
        trackBlocks.getBlockAtIndex(trainLoc).occupied=true;
    }
    public void setFailed(int failedBlock){
        trackBlocks.getBlockAtIndex(failedBlock).failure=true;
    }
    public void setWorking(int workingBlock){
        trackBlocks.getBlockAtIndex(workingBlock).failure=false;
    }
    public void setState(boolean s, int bNum){
        trackBlocks.getBlockAtIndex(bNum).state=s;
    }
    public void setSpeed(double s, int bNum){
        trackBlocks.getBlockAtIndex(bNum).speedLimit=s;
    }
    public void setAuth(int auth, int bNum){
        trackBlocks.getBlockAtIndex(bNum).authority=auth;
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        new TrackCont_Wrap();
    }
    
}
