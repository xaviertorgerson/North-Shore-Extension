/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Jeff
 */
public class TrackCont_TrackBlock {
    int blockNum;
    int type;
    int nextBlock;
    int prevBlock;
    int altPrevBlock;
    int altNextBlock;
    double speedLimit;
    int authority;
    boolean occupied;
    boolean state;
    boolean failure;
    boolean heater;
    
    public TrackCont_TrackBlock(int num,int t,boolean o,boolean s,boolean f,boolean h){
        blockNum=num;
        type=t;
        occupied=o;
        state=s;
        failure=f;
        heater=h;
        speedLimit=12.0;
        authority=2;
        nextBlock=-1;
    }
    public TrackCont_TrackBlock(int num,int t,boolean o,boolean s,boolean f,boolean h,int next){
        blockNum=num;
        type=t;
        occupied=o;
        state=s;
        failure=f;
        heater=h;
        nextBlock=next;
        speedLimit=12.0;
        authority=2;
        
    }
    public TrackCont_TrackBlock(int num,int t,int next,int prev){
        blockNum=num;
        type=t;
        occupied=false;
        state=false;
        failure=false;
        heater=false;
        nextBlock=next;
        prevBlock=prev;
        speedLimit=12.0;
        authority=2;
        altPrevBlock=-1;
        altNextBlock=-1;
        
    }
    public TrackCont_TrackBlock(int num,int t,int next,int prev, int aNext, int aPrev){
        blockNum=num;
        type=t;
        occupied=false;
        state=false;
        failure=false;
        heater=false;
        nextBlock=next;
        prevBlock=prev;
        altPrevBlock=aPrev;
        altNextBlock=aNext;
        speedLimit=12.0;
        authority=2;
    }
}
